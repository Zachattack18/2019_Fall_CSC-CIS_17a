/* 
 * File:   User.h
 * Author: Zachattack
 *
 * Created on October 19, 2019, 10:26 PM
 * Purpose: Create a header file that contains info on each player.
 */

#ifndef USER_H
#define USER_H

#include <string>

struct User {
    int points;         //holds points each player scores.
    std::string name;   //holds name of each player.
    char *rack;         //points to each player's rack that holds their tiles.
};

#endif /* USER_H */