/* 
 * File:   Square.h
 * Author: Zachattack
 *
 * Created on October 19, 2019, 10:39 PM
 * Purpose: Create a header file that contains info on each square 
 * on the game board.
 */

#ifndef SQUARE_H
#define SQUARE_H

#include <string>

struct Square {     //contains records about each square, location and multipliers
    int nCol;               //holds number of columns found on board game, only need to identify rows or columns, not both.
    std::string *colData;   //holds the strings that will be displayed on the board in each square.
};

#endif /* SQUARE_H */