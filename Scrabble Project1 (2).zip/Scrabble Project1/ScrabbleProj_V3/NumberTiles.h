/* 
 * File:   NumberTiles.h
 * Author: Zachattack
 *
 * Created on October 19, 2019, 10:25 PM
 * Purpose: Create a header file that contains info on each tile.
 */

#ifndef NUMBERTILES_H
#define NUMBERTILES_H

struct NumberTiles {
    char LtChar;    //holds the letter on each tile.
    int numTiles;   //holds the number of each lettered tile in the bag.
};

#endif /* NUMBERTILES_H */