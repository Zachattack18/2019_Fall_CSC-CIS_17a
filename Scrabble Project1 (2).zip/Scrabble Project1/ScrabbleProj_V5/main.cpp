/* 
 * File:   main.cpp
 * Author: Zachary Hill
 *
 * Created on October 1, 2019, 1:43 PM
 * Purpose: Create a program that simulates the Scrabble board game.
 * Final Version. Use the array of records to create the table/board with all
 * multipliers, notice that number of Records is not needed in the parameters
 * for print and destroy since both contain a pointer and nRecords is
 * already declared in Board.h. I also managed to create a nested structure
 * that points to the Square structure.
 */

//System Libraries
#include <cstdlib>      //rand(), dynamic memory allocation
#include <ctime>        //Time/Data utilities, srand()
#include <iostream>     //input/output commands
#include <iomanip>      //setw()
#include <fstream>      //File I/O
#include <cmath>        //Basic Math Functions,adding up points 
#include <cctype>       //tolower(),toupper()
#include <cstring>      //strings made up of characters
#include <string>       //strings
#include "NumberTiles.h"    //get information from header files.
#include "User.h"
#include "Board.h"
using namespace std;

//Global Constants
const int NUM = 27;
enum Letter{A, B, C, D, E, F, G, H, I, J, K, L, M, N,   //values that represent each character
            O, P, Q, R, S, T, U, V, W, X, Y, Z, BLANK}; //as integer constants. A=0, B=1, C=2,...
//Function Prototypes
bool openFileIn(ifstream &, string);
int displayTiles(NumberTiles *);
char *TileRack (NumberTiles *);
int TurnPlyr (int, int);
int score(string, int []);
Board *fillBoard(int, int);
void printBoard(const Board *);
void destroyBoard(Board *);

int main(int argc, char** argv) {
    srand ( time(NULL) ); //initialize the random seed.

    NumberTiles numTilesarr[NUM] = {{'A',9}, {'B',2}, {'C',2}, {'D',4}, {'E',12}, {'F',2}, {'G',3}, {'H',2}, {'I',9}, 
                            {'J',1}, {'K',1}, {'L',4}, {'M',2}, {'N',6}, {'O',8}, {'P',2}, {'Q',1}, {'R',6}, 
                            {'S',4}, {'T',6}, {'U',4}, {'V',2}, {'W',2}, {'X',1}, {'Y',2}, {'Z',1}, {'?', 2}};
    int ptTilesarr[NUM] = { 1, 3, 3, 2, 1, 4, 2, 4, 1, 8, 5, 1, 3, 1,
                        1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10, 0};
    char scrabbleLetters[] = {'A','B','C','D','E','F','G','H','I','J','K','L','M',
                          'N','O','P','Q','R','S','T','U','V','W','X','Y','Z', '?'};
    char again;         //holds response for a yes or no question.
    char input;         //data inputted to each file
    int nFields = 15;   //holds number of fields (individual pieces of data relating to a single thing).
    int nRecords = 15;  //holds the number of records (complete sets of data that relate to a single thing).
                        //columns are fields and rows are records since data and number of columns were both
                        //identified in a previous header file. With columns defined, you can determine rows.
    Board *rec;
    ifstream ruleFile, greetFile;
    fstream modruleFile, tileFile;
    ofstream playerFile;
    int length;     //how many characters are in each word
    char word[10]; //holds the word a player chooses within 10 characters.
    
    if(openFileIn(greetFile, "greet.txt")) {
        greetFile.get(input);	 //Read a character from file.
        while(greetFile) {	//while file is still open.
            cout << input;	//output message with all characters.
            greetFile.get(input);   //Read the next character from the file.
        }
        greetFile.close();      
    }
    cout << endl;
    
    cout << "Do you want to hear the rules? ";
    cin >> again;
    cout << endl;
    
    if (again == 'Y' || again == 'y') {
    modruleFile.open("modrules.txt", ios::in | ios::out);
    
    	if (openFileIn(ruleFile, "rules.txt")){
        	ruleFile.get(input);             //Read a character from file 1.
        	modruleFile.put(toupper(input));    //Write first uppercase letter from file 1 to file 2.
        	cout << input;      //display the very first character
        	modruleFile.get(input); //gets each character in every new sentence that's been capitalized.
        	cout << input;      //display second character, which is already lowercase when written to modrules file.
        
        	while(ruleFile){     //continue on to next line if last read operation was successful.
            		ruleFile.get(input);    //Read another character from file 1.

            		modruleFile.put(tolower(input));    //Write lowercase character to file 2.
            		modruleFile.get(input);     //get each character that's been altered.
            		if(modruleFile.eof()) //if at the end of the filtered file, break out. Does not output extra (!).
               			break;
            		cout << input;      //helps display all characters in file
            
            		if (input == '\n') {
                		ruleFile.get(input);    //Read another character after every newline in file 1.
                		modruleFile.put(toupper(input));  // Write uppercase character to file 2.
                		modruleFile.get(input);     //get first character in every new line that's been capitalized.
                		cout << input;
            		}
        	}
        	cout << endl;
        	ruleFile.close();
        	modruleFile.close();
    	}
    }
    
    cout << "\nHere's a list of all tiles and number of each in the game" << endl;
    cout << "---------------------------------------------------------\n";
    displayTiles(numTilesarr);
    cout << "\n\nNow here's the value of each lettered tile" << endl;
    cout << "----------------------------------------------\n";
    for (int count = 0; count < NUM - 1; count++) {
        cout << char(count + 65) << " = " << *(ptTilesarr+count);
        cout << setw(6);
    }
    cout << "   ? = " << ptTilesarr[26] << endl;
    
    tileFile.open("tile.bin", ios::out | ios::binary); 
    
    tileFile.write(scrabbleLetters, NUM);      //write all scrabble symbols to binary file
    
    tileFile.seekg(0L, ios::end);  //move to the last byte in the file
    tileFile.get(input);            //and read that character.
    cout << "Note: " << input << " is the blank space that can be used as any letter." << endl;
    
    tileFile.close();
    
    rec = fillBoard(nRecords, nFields);  //fill the board with the necessary rows and columns.
    
    printBoard(rec);    //print the board with all its characters.
    
    int numPlyrs = 0;   //number of players
    cout << "\nLet us begin! First, how many people are playing in this game? ";     //input number of players.
    cin >> numPlyrs;
    
    while (numPlyrs < 2 || numPlyrs > 4) {     //in case user inputs a number that does not qualify.
        cout << "\nInvalid number! There needs to be between 2 and 4 players." << endl;
        cout << "\nHow many people are playing in this game? ";     //input number of players.
        cin >> numPlyrs;
    }
    
    //Get names and have each player draw 7 tiles to begin.
    User *players = nullptr;
    players = new User [numPlyrs];    //create array with number of players.
    
    playerFile.open("players.txt", ios::out);
    
    for (int i = 0; i < numPlyrs; i++) {
        cout << "Enter the name of player #" << (i + 1) << ": ";    //each user will have a name
        cin >> players[i].name;
        
        playerFile << players[i].name << setw(10);      //write the latest player names into a file.

        players[i].rack = TileRack (numTilesarr);     //and a rack of tiles.
    }
    playerFile.close();
     
    //Begin playing the game.
    int totScore = 0; //total points each player acquired.
    int turn = 0;       //holds a player's turn.
    int topPlyr = players[0].points;    //player with the most points.
    do {
        TurnPlyr (numPlyrs, turn);
    
        cout << "Type the word you wish to use, or press enter if you have none : ";
        cin >> word;
        
	cout << "How many characters are in the word you want to make? ";
        cin >> length;

        totScore += score(word, ptTilesarr);
    
        for (int index=0; index < numPlyrs; index++) {  //go through all total score of
            if (players[index].points > totScore) {     //each player to see which score is
                totScore = players[index].points;       //currently the highest as well as
                topPlyr = index;                        //which player possesses that score.
            }
        }
        cout << "\nAny more words to spell, Y or N? \n";
        cin >> again;
        cout << endl;   
    } while(again == 'Y' || again == 'y');
    
    cout << players[topPlyr].name << " is the winner with a score of " << 
            totScore << "." << endl;
         
    destroyBoard(rec);
    delete [] players;
    players = nullptr;
    return 0;
}

bool openFileIn(ifstream &file, string name) {
    file.open(name, ios::in);
    if (file.fail())
        return false;
    else
        return true;
}

char *TileRack (NumberTiles *arr) {     //points to each player so they all have a rack.
    int randIndex;
    char *drawTile = nullptr;
    drawTile = new char [7];      //new character array where 7 character tiles are drawn.
    for (int i = 0; i < 7; i++) {
        randIndex = rand()%NUM;   //random index for array between 0-26.
        
        while(arr[randIndex].numTiles == 0) {   //have the program generate a new random index
            randIndex = rand()%NUM;             //if the lettered tile within that index of the array
        }                                       //no longer exists in the bag, or zero in the array.
        
            drawTile[i] = arr[randIndex].LtChar;    //assign drawTile as character from the array based on its index.
            arr[randIndex].numTiles -= 1;   //decrement number of that specific tile. 
            cout << "Tile drawn: " << drawTile[i] << endl; //display all lettered tiles.
    }
    return drawTile;    //return array of objects.
}

int TurnPlyr (int numplyrs, int turn) { //used to determine which player's turn
        turn++;                         //it is as the game goes on.
        if (turn >= numplyrs)
            turn = 0;       //reset turn
        
    return turn;
}

int score(string s, int ptarr[]) {
    int points = 0;
    int c;         //each character in word chosen.
    int pos;       //position on board the player chooses to place tile.
    int len = sizeof(s);
    for (int i = 0; i < len; i++) {
        char ch = s[i];             //ch is equal to an individual letter based on its position in the word.

            cout << "Now enter where you want to place each lettered tile on the" << 
                    " board based on the index of each square (look at diagram above:" <<
                    " top-left=0,top-right=14, bottom-right=224, etc.) and in order" << 
                    " of how you your word, press entered after each number entered: ";
            cin >> pos;
        
            //multiply letters and/or words if a tile is placed in a specific square.
            if (pos==0 || pos==7 || pos==14 || pos==105 || pos==119 || pos==217 || pos==210 ||pos==224) {
                ptarr[ch - 97] *= 3;  //triple word
                points += ptarr[ch - 97];
            }
            else if (pos==16 || pos==28 || pos==32 || pos==42 || pos==48 || pos==56 ||
                pos==64 || pos==70 || pos==112 || pos==154 || pos==160 ||
                pos==168 || pos==176 || pos==182 || pos==192 || pos==196 || pos==208) {
                ptarr[ch - 97] *= 2;  //double word
                points += ptarr[ch - 97];
            }
            else if (pos==20 || pos==24 || pos==76 || pos==80 || pos==84 || pos==88 ||
                pos==136 || pos==140 || pos==144 || pos==148 || pos==200 || pos==204) {
                c = (ch-97);
                c *= 3;     //triple letter
                points += ptarr[c];
            }
            else if (pos==3 || pos==11 || pos==36 || pos==38 || pos==45 || pos==52 ||
                pos==59 || pos==92 || pos==96 || pos==98 || pos==102 || pos==108 ||
                pos==116 || pos==122 || pos==126 || pos==128 || pos==132 ||
                pos==165 || pos==172 || pos==179 || pos==186 || pos==188 ||
                pos==213 || pos==221) {
                c = (ch-97);
                c *= 2;     //double letter
                points += ptarr[c];
            }
            else {
                points += ptarr[ch - 97];   //convert letter from ASCII code to index, then use that index to locate points
                                            // that letter in array, all points in word are then added together.
            }                                   
    }
   return points;
}

int displayTiles(NumberTiles *array) {    
    for (int index = A; index <= BLANK; index++) {  //use the constant integers in enum as the indexes
                                                    //to find and read the characters in array.
        cout << array[index].LtChar << " = ";    //display character found in array
        
        array[index].numTiles > 0 ? cout << right << array[index].numTiles      //used to determine number of each
            << setw(6) : cout << right << "ALL OUT" << setw(6);                 //remaining tile still in bag.  
    }
}

Board *fillBoard(int nRecords, int nColumns) {
    Board *board = new Board;       //allocate a new array that points to each
    board->nRecords=nRecords;       //variable in Board structure.
    board->nFields=nColumns;
    board->record= new Square[board->nRecords];

    //Initialize Variables, number of columns/fields and strings in each square
    for (int row = 0; row < nRecords; row++) {
        board->record[row].nCol = board->nFields;
        board->record[row].colData = new string [board->record[row].nCol];
    }

    //Process inputs to outputs/map
    for (int row = 0; row < board->nRecords; row++) {
        for (int col = 0; col < board->record[row].nCol; col++) {
            board->record[row].colData[col] = "X";//filling all squares on board with standard spaces
            if (row == 1 || row == 5 || row == 9 || row == 13){
                if(col == 1 || col == 5 || col == 9 || col == 13)
                    board->record[row].colData[col] = "TL";	//input triple letter multiplier
            }
            if (row == 3 || row == 11){
                if(col == 0 || col == 7 || col == 14)
                    board->record[row].colData[col] = "DL";	//input double letter multiplier
            }
            if (row == 0 || row == 7 || row == 14){
                if(col == 3 || col == 11)
                    board->record[row].colData[col] = "DL";	
            }
            if (row == 2 || row == 6 || row == 8 || row == 12){
                if(col == 6 || col == 8)
                    board->record[row].colData[col] = "DL";	
            }
            if (row == 6 || row == 8){
                if(col == 2 || col == 6 || col == 8 || col == 12)
                    board->record[row].colData[col] = "DL";	
            }
            if (row == 0 || row == 7 || row == 14){
                if(col == 0 || col == 7 || col == 14)
                    board->record[row].colData[col] = "TW";	//input triple word multiplier       
            }
            if (row == 1 || row == 13){
                if(col == 1 || col == 13)
                    board->record[row].colData[col] = "DW";	//input double word multiplier
            }
            if (row == 2 || row == 12){
                if(col == 2 || col == 12)
                    board->record[row].colData[col] = "DW";	
            }
            if (row == 3 || row == 11){
                if(col == 3 || col == 11)
                    board->record[row].colData[col] = "DW";	
            }
            if (row == 4 || row == 10){
                if(col == 4 || col == 10)
                    board->record[row].colData[col] = " DW";	
            }
            board->record[7].colData[7] = "DW";   //replace TL in middle with DW
        }
    }
    return board;
}

void printBoard(const Board *board) {
	//Display the results
	cout << "Format of the Actual Board Game" << endl;
	for (int row = 0; row < board->nRecords; row++) {
		for (int col = 0; col < board->record[row].nCol; col++) {
			cout << board->record[row].colData[col] << " ";   //print symbols for each square
		}
		cout << endl;
	}
	cout << endl;
}

void destroyBoard(Board *board) {	//delete new variables that were declared dynamically.
	for (int row = 0; row < board->nRecords; row++) {
		delete[]board->record[row].colData;     //first delete contents of array
	}                                               
        delete [] board->record;    //then delete pointer that points to Array of Records
	delete[]board;              //and delete the array of pointers.
}