/* 
 * File:   Board.h
 * Author: Zachattack
 *
 * Created on October 19, 2019, 10:52 PM
 */

#ifndef BOARD_H
#define BOARD_H

#include "Square.h"

struct Board{
    int nFields;   //Number of Fields/Rows in the Board
    int nRecords;  //Number of Records/Columns in the Board
    Square *record;  //Array of Records, accesses variables from Square struct
};

#endif /* BOARD_H */